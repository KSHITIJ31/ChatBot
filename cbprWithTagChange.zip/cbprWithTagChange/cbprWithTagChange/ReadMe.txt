step1 -   start node cmd -->  go to project path --> node ExpressServer.js

step2 -  open another node cmd --> go to project path --> simplehttpserver

step3 - on crome -- localhost:8000 --> run chatbotfinal