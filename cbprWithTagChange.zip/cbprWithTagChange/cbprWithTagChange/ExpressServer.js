var express = require('express');
var app = express();
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

var http = require("https");


var jsonObj=null;


 var body;
var http = require("https");

var options = {
  "method": "POST",
  "hostname": "9xcwz56crk.execute-api.us-west-2.amazonaws.com",
  "port": null,
  "path": "/beta/",
  "headers": {
    "content-type": "application/json",
    "cache-control": "no-cache",
    "postman-token": "4ae98789-e0e5-76bf-fc32-e9f6caf7c87f"
  }
};

var req = http.request(options, function (res) {
  var chunks = [];

  res.on("data", function (chunk) {
    chunks.push(chunk);
  });

  res.on("end", function () {
     body= Buffer.concat(chunks);
    jsonObj = JSON.parse(body.toString());
	console.log(jsonObj);
  
  });
});



req.write(JSON.stringify({ sessionId: 16474665634717696 }));
req.end();





app.use('/data', function(req, res){
	res.send(body);
 //replace with your data here
});





 /*function showChat() {


      var sessionvalue = document.getElementById('sessionId').value;*/

      /*alert(sessionvalue);
*/
     /*sessionArray = ["16473292734267392","16438001682243584","16474665634717696","16440018727821312"];

        sessionArrayLength = sessionArray.length;

        for (i = 0; i < sessionArrayLength; i++) {
           
            if(sessionvalue == sessionArray[i])
            {

     */           //code

                   /* var jsonObj=null;


                       var body;
                      

                      var options = {
                        "method": "POST",
                        "hostname": "9xcwz56crk.execute-api.us-west-2.amazonaws.com",
                        "port": null,
                        "path": "/beta/",
                        "headers": {
                          "content-type": "application/json",
                          "cache-control": "no-cache",
                          "postman-token": "4ae98789-e0e5-76bf-fc32-e9f6caf7c87f"
                        }
                      };




            req.write(JSON.stringify({ sessionvalue }));
            req.end();




              app.use('/data', function(req, res){
                res.send(body);
               //replace with your data here
              });



          
      
    }

*/




app.listen(3000);
console.log("Server is running");